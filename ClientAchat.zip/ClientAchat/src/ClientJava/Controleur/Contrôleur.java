package ClientJava.Controleur;

import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.DAO.AuteurDAO;
import ServeurJava.Model.DAO.SujetDAO;
import ServeurJava.Model.DAO.LivreDAO;
import ClientJava.Vue.InterfacesGraphiques.FenetreClient;
import ClientJava.Vue.InterfacesGraphiques.LoginWindow;

import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class Contrôleur implements ActionListener
{
    private AuteurDAO auteurDAO;
    private SujetDAO sujetDAO;
    private LivreDAO livreDAO;

    private LoginWindow loginWindow;
    private FenetreClient fenetreClient;

    public Contrôleur()
    {
        try
        {
            // Initialisation des DAO
            this.auteurDAO = new AuteurDAO();
            this.sujetDAO = new SujetDAO();
            this.livreDAO = new LivreDAO(new ConnexionBD(""));
        }
        catch (SQLException | ClassNotFoundException e)
        {
            JOptionPane.showMessageDialog(null, "Erreur lors de l'initialisation des DAO : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }

    /*public Contrôleur(RecupererDAO recupererDAO, LoginWindow loginWindow)
    {
        this.recupererDAO = recupererDAO;
        this.loginWindow = loginWindow;
        this.loginWindow.setControleur(this);
    }*/

    public void setControleurAchat(FenetreClient fenetreClient)
    {
        this.fenetreClient = fenetreClient;
        FenetreClient.getFenetreClient().ajouterActionListener(this);
    }

    public void run()
    {
        this.loginWindow.run();
    }

    @Override
    public void actionPerformed(ActionEvent event)
    {
        try
        {
            String action = event.getActionCommand();

            if (action.equals(ActionsContrôleur.LOGIN_ACHAT))
            {
               // LoginWindow.getLoginWindow().LoginAchat();
                FenetreClient.getFenetreClient();
                setControleurAchat(fenetreClient);
            }


            if (action.equals(ActionsContrôleur.LOGOUT_ACHAT))
            {
                FenetreClient.getFenetreClient().Logout();
            }

            if (action.equals(ActionsContrôleur.SELECTIONNER_LIVRE))
            {
                // Sélectionner tous les livres
                FenetreClient.getFenetreClient().Selectionner();
            }

            if (action.equals(ActionsContrôleur.AJOUT_ARTICLE))
            {
                FenetreClient.getFenetreClient().Ajouter();
                JOptionPane.showMessageDialog(null, "Article ajouté au panier !");
            }

            if (action.equals(ActionsContrôleur.SUPPRIMER_ARTICLE))
            {
                FenetreClient.getFenetreClient().Supprimer();
                JOptionPane.showMessageDialog(null, "Article supprimé du panier !");
            }

            if (action.equals(ActionsContrôleur.EFFACER_PANIER))
            {
                FenetreClient.getFenetreClient().Annuler();
                JOptionPane.showMessageDialog(null, "Panier effacé !");
            }

            if (action.equals(ActionsContrôleur.PAYER_PANIER))
            {
                FenetreClient.getFenetreClient().Payer();
                JOptionPane.showMessageDialog(null, "Paiement effectué !");
            }
        }
        catch (Exception e)
        {
            JOptionPane.showMessageDialog(null, "Erreur lors du traitement de l'action : " + e.getMessage(), "Erreur", JOptionPane.ERROR_MESSAGE);
            e.printStackTrace();
        }
    }
}
