package ClientJava.Controleur;

public class ActionsContrôleur
{
    public static final String LOGIN_ACHAT = "login_achat";
    public static final String LOGOUT_ACHAT = "logout_achat";
    public static final String SELECTIONNER_LIVRE= "sélectionner_livre";
    public static final String AJOUT_ARTICLE = "ajout_article";
    public static final String SUPPRIMER_ARTICLE = "supprimer_article";
    public static final String EFFACER_PANIER = "effacer_panier";
    public static final String PAYER_PANIER = "payer_panier";

}
