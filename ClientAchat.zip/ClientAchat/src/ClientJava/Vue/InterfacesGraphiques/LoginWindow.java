package ClientJava.Vue.InterfacesGraphiques;

import ClientJava.Controleur.ActionsContrôleur;
import ServeurJava.Logger.Logger;
import ClientJava.Vue.InterfacesGraphiques.FenetreClient;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;

public class LoginWindow extends JFrame
{
    private JTextField UsernameField;
    private JPasswordField PasswordField;
    private JButton LoginButton2;
    private JComboBox<String> userTypeComboBox;
    private JPanel MainPanel;

    private LoginWindow loginWindow;

    private static LoginWindow instance;

    public static LoginWindow getLoginWindow()
    {
        if (instance == null)
        {
            instance = new LoginWindow();
        }
        return instance;
    }

    private Logger logger;


    public LoginWindow()
    {
        super("Login...");
        setSize(350, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        MainPanel = new JPanel();
        MainPanel.setLayout(new GridLayout(0, 2)); // Utilisation d'un GridLayout pour mieux organiser les composants

        UsernameField = new JTextField(20);
        PasswordField = new JPasswordField(20);
        LoginButton2 = new JButton("Client Achat");

        // Ajout de la JComboBox
        userTypeComboBox = new JComboBox<>(new String[] {"Nouveau Utilisateur", "Utilisateur Existant"});

        // Ajout des composants au panneau principal
        MainPanel.add(new JLabel("Username:"));
        MainPanel.add(UsernameField);
        MainPanel.add(new JLabel("Password:"));
        MainPanel.add(PasswordField);
        MainPanel.add(new JLabel("Type d'utilisateur:"));
        MainPanel.add(userTypeComboBox);
        MainPanel.add(LoginButton2);

        setContentPane(MainPanel);
    }

    public String getUsername() {
        return UsernameField.getText();
    }

    public String getPassword() {
        return new String(PasswordField.getPassword());
    }

    // Méthode pour ajouter un listener sur le bouton "Client Achat"
    public void addLogin2Listener(ActionListener listener) {
        LoginButton2.addActionListener(listener);
    }

    // Méthode pour afficher un message
    public void showMessage(String message)
    {
        JOptionPane.showMessageDialog(this, message);
    }

    public void run()
    {
        this.loginWindow = this;
        setVisible(true);
    }

    public void setControleur(ActionListener listener)
    {
        this.loginWindow = this;

        LoginButton2.addActionListener(listener);

        LoginButton2.setActionCommand(ActionsContrôleur.LOGIN_ACHAT);
    }

    /*public void LoginAchat()
    {
        String username = getUsername();
        String password = getPassword();

        if (username.isEmpty() || password.isEmpty())
        {
            showMessage("Veuillez entrer un nom d'utilisateur et un mot de passe.");
            return;
        }

        String userType = (String) userTypeComboBox.getSelectedItem();
        if ("Nouveau Utilisateur".equals(userType))
        {
            Requetes requetes = new Requetes(logger);
            requetes.AjoutUtilisateur(username, password);
            return;
        }

        Requetes requetes = new Requetes(logger);
        if (!requetes.userExists(username))
        {
            showMessage("Utilisateur introuvable. Vérifiez le nom d'utilisateur.");
            return;
        }

        LOGIN login = new LOGIN(username, password);
        boolean loginResult = requetes.Login(login);

        if (loginResult)
        {
            showMessage("Bienvenue dans l'interface d'encodage !");
            FenetreClient fenetreClient = FenetreClient.getFenetreClient();
            fenetreClient.setUsername(username);
            fenetreClient.RecupererLivres();
            fenetreClient.setVisible(true);
        }
        else
        {
            showMessage("Mot de passe incorrect. Veuillez réessayer.");
        }
    }*/

    public static void main(String[] args)
    {
        LoginWindow loginWindow1 = LoginWindow.getLoginWindow();
        loginWindow1.setVisible(true);
    }
}
