package ClientJava.Vue.InterfacesGraphiques;

import ClientJava.Controleur.ActionsContrôleur;
import ServeurJava.Model.DAO.LivreDAO;
import ServeurJava.Model.Entites.Auteur;
import ServeurJava.Model.Entites.Livre;
import ServeurJava.Model.Entites.Sujet;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FenetreClient extends JFrame
{
    private JTextField UsernameField;

    public JTextField getUsername()
    {
        return UsernameField;
    }

    public void setUsername(String username)
    {
        UsernameField.setText(username);
    }

    private JTextField AuthorField;

    public JTextField getAuthorField()
    {
        return AuthorField;
    }

    public void setAuthorField(JTextField authorField)
    {
        AuthorField = authorField;
    }

    private JTextField TitleField;

    public JTextField getTitleField()
    {
        return TitleField;
    }

    public void setTitleField(JTextField titleField)
    {
        TitleField = titleField;
    }

    private JTextField PriceField;

    public JTextField getPriceField()
    {
        return PriceField;
    }

    public void setPriceField(JTextField priceField)
    {
        PriceField = priceField;
    }

    private JButton Selectionner;

    public JButton getSelectionner()
    {
        return Selectionner;
    }

    private JButton Ajouter;

    public JButton getAjouter()
    {
        return Ajouter;
    }

    private JButton Supprimer;

    public JButton getSupprimer()
    {
        return Supprimer;
    }

    private JButton Annuler;

    public JButton getAnnuler()
    {
        return Annuler;
    }

    private JButton Payer;

    public JButton getPayer()
    {
        return Payer;
    }

    private JButton Logout;

    public JButton getLogout()
    {
        return Logout;
    }

    private JPanel TopPanel;

    public JPanel getTopPanel()
    {
        return TopPanel;
    }

    private JScrollPane Scroll;

    public JScrollPane getScroll()
    {
        return Scroll;
    }

    private JTable ClientTable;

    public JTable getClientTable()
    {
        return ClientTable;
    }

    private DefaultTableModel TableDefaut;

    public DefaultTableModel getTableDefaut()
    {
        return TableDefaut;
    }

    private static FenetreClient instance;

    public static FenetreClient getFenetreClient()
    {
        if(instance == null)
        {
            instance = new FenetreClient();
        }

        return instance;
    }

    public FenetreClient()
    {
        super("Fenetre Java de Client Achat");

        this.setSize(800, 500);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setLayout(new BorderLayout());

        // Panneau supérieur (TopPanel avec boutons)
        TopPanel = new JPanel();
        TopPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        UsernameField = new JTextField("Utilisateur");
        UsernameField.setEditable(false);
        AuthorField = new JTextField("Nom Auteur");
        TitleField = new JTextField("Titre Livre");
        PriceField = new JTextField("Prix Livre");
        // Augmenter la taille des JTextField
        AuthorField.setPreferredSize(new java.awt.Dimension(200, 20));
        TitleField.setPreferredSize(new java.awt.Dimension(200, 20));
        PriceField.setPreferredSize(new java.awt.Dimension(50, 20));

        Selectionner = new JButton("Sélectionner");
        Ajouter = new JButton("Ajouter");
        Supprimer = new JButton("Supprimer");
        Annuler = new JButton("Annuler");
        Payer = new JButton("Payer");
        Logout = new JButton("Logout");

        TopPanel.add(UsernameField);
        TopPanel.add(AuthorField);
        TopPanel.add(TitleField);
        TopPanel.add(PriceField);
        TopPanel.add(Selectionner);
        TopPanel.add(Ajouter);
        TopPanel.add(Supprimer);
        TopPanel.add(Annuler);
        TopPanel.add(Payer);
        TopPanel.add(Logout);

        this.add(TopPanel, BorderLayout.NORTH);

        // Table des livres
        String[] Colonnes = {"Auteur", "Titre", "Sujet", "ISBN", "Quantite", "Prix"};
        TableDefaut = new DefaultTableModel(Colonnes, 0);
        ClientTable = new JTable(TableDefaut);
        ClientTable.setModel(TableDefaut);
        ClientTable.setAutoResizeMode(JTable.AUTO_RESIZE_ALL_COLUMNS);
        Scroll = new JScrollPane(ClientTable);
        this.add(Scroll, BorderLayout.SOUTH); // Ajout de la table sous le panneau des champs
    }

    public void ShowMessage(String  Message)
    {
        JOptionPane.showMessageDialog(this, Message);
    }

    public void ajouterActionListener(ActionListener listener)
    {
        Selectionner.addActionListener(listener);
        Ajouter.addActionListener(listener);
        Supprimer.addActionListener(listener);
        Annuler.addActionListener(listener);
        Payer.addActionListener(listener);
        Logout.addActionListener(listener);

        Selectionner.setActionCommand(ActionsContrôleur.SELECTIONNER_LIVRE);
        Ajouter.setActionCommand(ActionsContrôleur.AJOUT_ARTICLE);
        Supprimer.setActionCommand(ActionsContrôleur.SUPPRIMER_ARTICLE);
        Annuler.setActionCommand(ActionsContrôleur.EFFACER_PANIER);
        Payer.setActionCommand(ActionsContrôleur.PAYER_PANIER);
        Logout.setActionCommand(ActionsContrôleur.LOGOUT_ACHAT);
    }

    public void Selectionner() throws SQLException, ClassNotFoundException
    {
        /*List<Livre> livres = LivreDAO.();
        StringBuilder message = new StringBuilder("Liste des livres :\n");
        for (Livre livre : livres)
        {
            message.append(livre).append("\n");
        }

        ShowMessage(message.toString());*/
    }

    public void Ajouter()
    {

    }

    public void Supprimer()
    {

    }

    public void Annuler()
    {

    }

    public void Payer()
    {

    }
    public void Logout()
    {
        ShowMessage("Au revoir");
        this.setVisible(false);
    }

    public void RecupererLivres()
    {
        /*try
        {
            Map<Integer, String> auteursMap = new HashMap<>();
            Map<Integer, String> sujetsMap = new HashMap<>();

            List<Auteur> auteurs = AuteurDAO.getInstance().recupererTousLesAuteurs();
            for (Auteur auteur : auteurs)
            {
                auteursMap.put(auteur.getId(), auteur.getPrenom() + " " + auteur.getNom());
            }

            List<Sujet> sujets = SujetDAO.getInstance().recupererTousLesSujets();
            for (Sujet sujet : sujets)
            {
                sujetsMap.put(sujet.getId(), sujet.getNom());
            }

            List<Livre> livres = LivreDAO.getInstance().recupererTousLesLivres();
            DefaultTableModel model = (DefaultTableModel) ClientTable.getModel();
            model.setRowCount(0);

            for(Livre livre : livres)
            {
                String nomAuteur = auteursMap.getOrDefault(livre.getIdAuteur(), "Auteur inconnu");
                String nomSujet = sujetsMap.getOrDefault(livre.getIdSujet(), "Sujet inconnu");

                model.addRow(new Object[]{nomAuteur, livre.getTitre(), nomSujet, livre.getISBN(), livre.getQuantite(), livre.getPrix()});
            }
        }

        catch(SQLException | ClassNotFoundException e)
        {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Erreur lors de la récupération des sujets : " + e.getMessage());
        }*/
    }

    public static void main(String[] args)
    {
        FenetreClient fenetreClient = FenetreClient.getFenetreClient();
        fenetreClient.setVisible(true);
    }
}
