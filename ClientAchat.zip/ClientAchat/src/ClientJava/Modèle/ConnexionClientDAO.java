package ClientJava.Modèle;

import ServeurJava.Model.Base_De_Données.Reponses.AjouterArticleReponse;
import ServeurJava.Model.Base_De_Données.Reponses.ClientReponse;
import ServeurJava.Model.Base_De_Données.Reponses.PayerPanierReponse;
import ServeurJava.Model.Base_De_Données.Reponses.SupprimerArticleReponse;
import ServeurJava.Model.Base_De_Données.Requetes.*;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

public class ConnexionClientDAO
{
    private final Socket socket;

    private final ObjectOutputStream objectOutputStream;

    private final ObjectInputStream objectInputStream;

    public ConnexionClientDAO(String ip, int port)throws Exception
    {
        this.socket = new Socket(ip, port);
        this.objectOutputStream = new ObjectOutputStream(socket.getOutputStream());
        this.objectInputStream = new ObjectInputStream(socket.getInputStream());
    }

    public ClientReponse envoyerRequeteClient(ClientRequete clientRequete)throws Exception
    {
        objectOutputStream.writeObject(clientRequete);
        return (ClientReponse) objectInputStream.readObject();
    }

    public AjouterArticleReponse envoyerRequeteAJoutArticle(AjouterArticleRequete ajouterArticleRequete)throws Exception
    {
        objectOutputStream.writeObject(ajouterArticleRequete);
        return (AjouterArticleReponse) objectInputStream.readObject();
    }

    public SupprimerArticleReponse envoyerRequeteSupprimerArticle(SupprimerArticleRequete supprimerArticleRequete)throws Exception
    {
        objectOutputStream.writeObject(supprimerArticleRequete);
        return (SupprimerArticleReponse) objectInputStream.readObject();
    }

    public EffacerPanierRequete envoyerRequeteEffacerPanier(EffacerPanierRequete effacerPanierRequete)throws Exception
    {
        objectOutputStream.writeObject(effacerPanierRequete);
        return (EffacerPanierRequete) objectInputStream.readObject();
    }

    public PayerPanierReponse envoyerRequetePayerPanier(PayerPanierRequete payerPanierRequete)throws Exception
    {
        objectOutputStream.writeObject(payerPanierRequete);
        return (PayerPanierReponse) objectInputStream.readObject();
    }

    public void close() throws Exception
    {
        objectInputStream.close();
        objectOutputStream.close();
        socket.close();
    }


}
