package ServeurJava.Logger;

public interface Logger
{
    void Trace(String Message);
}
