package ServeurJava.DemarrerServeur;

import ServeurJava.Reseaux.Protocole.BSPP;

public class Serveur
{
    public static void main(String[] args)
    {
        ServeurBSPP serveurBSPP = new ServeurBSPP();
        serveurBSPP.demarrer();
    }
}
