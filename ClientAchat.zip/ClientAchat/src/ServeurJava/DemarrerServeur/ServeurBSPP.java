package ServeurJava.DemarrerServeur;

import ServeurJava.Logger.Logger;
import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Reseaux.Protocole.BSPP;
import ServeurJava.Reseaux.Threads.Demande.ServeurThreadDemande;
import ServeurJava.Reseaux.Threads.ServeurThread;


public class ServeurBSPP
{
    private ServeurThread serveurThread;

    public ServeurBSPP()
    {

    }

    public void demarrer() {
        try {
            ConnexionBD connexionBD = ConnexionBD.getInstance();
            serveurThread = new ServeurThreadDemande(50000, new BSPP(connexionBD), (Logger) this);  // Si ServeurBSPP implémente Logger
            serveurThread.start();
        } catch (Exception ex) {
            // Gérer les exceptions
        }
    }

    public static void main(String[] args)
    {
        ServeurBSPP serveur = new ServeurBSPP();
        serveur.demarrer();
    }



}
