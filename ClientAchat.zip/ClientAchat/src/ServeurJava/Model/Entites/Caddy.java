package ServeurJava.Model.Entites;

import java.io.Serializable;
import java.time.LocalDate;

public class Caddy implements Serializable
{
    private Integer id;
    private Integer idClient;
    private LocalDate date;
    private Double montant;
    private Boolean paye;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public Integer getIdClient()
    {
        return idClient;
    }

    public void setIdClient(Integer idClient)
    {
        this.idClient = idClient;
    }

    public LocalDate getDate()
    {
        return date;
    }

    public void setDate(LocalDate date)
    {
        this.date = date;
    }

    public Double getMontant()
    {
        return montant;
    }

    public void setMontant(Double montant)
    {
        this.montant = montant;
    }

    public Boolean getPaye()
    {
        return paye;
    }

    public void setPaye(Boolean paye)
    {
        this.paye = paye;
    }

    public Caddy()
    {
        this.id = null;
        this.idClient = null;
        this.date = null;
        this.montant = null;
        this.paye = null;
    }

    public Caddy(Integer id, Integer idClient, LocalDate date, Double montant, Boolean paye)
    {
        this.id = id;
        this.idClient = idClient;
        this.date = date;
        this.montant = montant;
        this.paye = paye;
    }
}
