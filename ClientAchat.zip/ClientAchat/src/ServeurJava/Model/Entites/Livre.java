package ServeurJava.Model.Entites;

import java.io.Serializable;

public class Livre implements Serializable
{
    private Integer Id;
    private String NomAuteur;
    private String NomSujet;
    private String Titre;
    private String ISBN;
    private Integer NombrePages;
    private Integer Quantite;
    private Float Prix;
    private Integer AnneePublication;

    public Integer getId()
    {
        return Id;
    }

    public void setId(Integer id)
    {
        this.Id = id;
    }

    public String getNomAuteur()
    {
        return NomAuteur;
    }

    public void setNomAuteur(String nomAuteur)
    {
        this.NomAuteur = nomAuteur;
    }

    public String getNomSujet()
    {
        return NomSujet;
    }

    public void setNomSujet(String nomSujet)
    {
        this.NomSujet = nomSujet;
    }

    public String getTitre()
    {
        return Titre;
    }

    public void setTitre(String titre)
    {
        this.Titre = titre;
    }

    public String getISBN()
    {
        return ISBN;
    }

    public void setISBN(String isbn)
    {
        this.ISBN = isbn;
    }

    public Integer getNombrePages()
    {
        return NombrePages;
    }

    public void setNombrePages(Integer nombrePages)
    {
        this.NombrePages = nombrePages;
    }

    public Integer getQuantite()
    {
        return Quantite;
    }

    public void setQuantite(Integer quantite)
    {
        this.Quantite = quantite;
    }

    public float getPrix()
    {
        return Prix;
    }

    public void setPrix(Float prix)
    {
        this.Prix = prix;
    }

    public int getAnneePublication()
    {
        return AnneePublication;
    }

    public void setAnneePublication(Integer anneePublication)
    {
        this.AnneePublication = anneePublication;
    }

    @Override
    public String toString()
    {
        return "Livre{" +
                "Id=" + Id +
                ", NomAuteur=" + NomAuteur +
                ", NomSujet=" + NomSujet +
                ", Titre='" + Titre + '\'' +
                ", ISBN='" + ISBN + '\'' +
                ", NombrePages=" + NombrePages +
                ", Quantite=" + Quantite +
                ", Prix=" + Prix +
                ", AnneePublication=" + AnneePublication +
                '}';
    }

    public Livre()
    {
        this.Id = null;
        this.NomAuteur = null;
        this.NomSujet = null;
        this.Titre = null;
        this.ISBN = null;
        this.NombrePages = null;
        this.Quantite = null;
        this.Prix = null;
        this.AnneePublication = null;
    }


    public Livre(Integer id, String nomAuteur, String nomSujet, String titre, String isbn,
                 Integer nombrePages, Integer quantite, Float prix, Integer anneePublication)
    {
        this.Id = id;
        this.NomAuteur = nomAuteur;
        this.NomSujet = nomSujet;
        this.Titre = titre;
        this.ISBN = isbn;
        this.NombrePages = nombrePages;
        this.Quantite = quantite;
        this.Prix = prix;
        this.AnneePublication = anneePublication;
    }
}
