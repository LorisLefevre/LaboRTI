package ServeurJava.Model.Entites;

public interface Entite
{

}
