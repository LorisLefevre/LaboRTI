package ServeurJava.Model.Tests;

import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.Entites.Client;
import ServeurJava.Model.ViewModel.RechercheClientVM;
import ServeurJava.Model.DAO.ClientDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class TestClientDAO {

    public static void main(String[] args) throws Exception {
        ConnexionBD connexionBD = ConnexionBD.getInstance();
        ClientDAO clientDAO = new ClientDAO(connexionBD);

        // Test de la méthode loadClient avec des critères de recherche
        //testLoadClient(clientDAO);

        // Test de la méthode sauvegarder
        testSauvegarder(clientDAO);
    }

    public static void testLoadClient(ClientDAO clientDAO) {
        System.out.println("Test loadClient...");

        try {
            // Recherche sans critères (devrait renvoyer tous les clients)
            RechercheClientVM searchCriteria1 = new RechercheClientVM(null, null, null);
            ArrayList<Client> clients1 = clientDAO.loadClient(searchCriteria1);
            System.out.println("Clients récupérés (sans critères) : " + clients1.size());

            // Recherche avec un critère (par exemple, le nom)
            RechercheClientVM searchCriteria2 = new RechercheClientVM(null, "Doe", null);
            ArrayList<Client> clients2 = clientDAO.loadClient(searchCriteria2);
            System.out.println("Clients récupérés (avec nom = 'Doe') : " + clients2.size());

            // Recherche avec des critères plus détaillés
            RechercheClientVM searchCriteria3 = new RechercheClientVM(1, "John", "Doe");
            ArrayList<Client> clients3 = clientDAO.loadClient(searchCriteria3);
            System.out.println("Clients récupérés (ID=1, nom='John', prénom='Doe') : " + clients3.size());

        } catch (SQLException e) {
            System.out.println("Erreur lors de la récupération des clients : " + e.getMessage());
        }
    }

    public static void testSauvegarder(ClientDAO clientDAO) {
        System.out.println("Test sauvegarder...");

        try {
            // Création d'un nouveau client
            Client client = new Client();
            client.setNom("John");
            client.setPrenom("Doe");

            // Sauvegarder le client
            clientDAO.sauvegarder(client);

            System.out.println("Client sauvegardé : " + client.getId() + " - " + client.getNom() + " " + client.getPrenom());

            // Vérifier si le client existe maintenant dans la base de données
            RechercheClientVM searchCriteria = new RechercheClientVM(null, "John", "Doe");
            ArrayList<Client> clients = clientDAO.loadClient(searchCriteria);

            if (!clients.isEmpty()) {
                System.out.println("Le client 'John Doe' a bien été ajouté.");
            } else {
                System.out.println("Erreur : Le client 'John Doe' n'a pas été ajouté.");
            }

        } catch (Exception e) {
            System.out.println("Erreur lors de la sauvegarde du client : " + e.getMessage());
        }
    }
}

