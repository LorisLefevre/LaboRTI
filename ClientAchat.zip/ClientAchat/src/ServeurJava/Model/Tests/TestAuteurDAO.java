package ServeurJava.Model.Tests;


import ServeurJava.Model.Entites.Auteur;
import ServeurJava.Model.ViewModel.RechercheAuteurVM;
import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.DAO.AuteurDAO;

import java.sql.SQLException;
import java.util.ArrayList;

public class TestAuteurDAO {

    public static void main(String[] args) {
        try {
            // Initialisation
            ConnexionBD connexionBD = ConnexionBD.getInstance();
            AuteurDAO auteurDAO = new AuteurDAO();

            // Tests
            //testInsertAuteur(auteurDAO);
            //testUpdateAuteur(auteurDAO);
            testDeleteAuteur(auteurDAO);
            testLoadAuteurWithSearchCriteria(auteurDAO);

            // Fermeture de la connexion
            connexionBD.Close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void testInsertAuteur(AuteurDAO auteurDAO) {
        System.out.println("Test: testInsertAuteur");
        try {
            Auteur nouvelAuteur = new Auteur("Dupont", "Jean", "1980-05-15");
            auteurDAO.save(nouvelAuteur);

            // Vérifications
            if (nouvelAuteur.getId() == null || nouvelAuteur.getId() <= 0) {
                throw new AssertionError("Échec: l'ID de l'auteur n'a pas été généré.");
            }

            Auteur auteurCharge = auteurDAO.getById(nouvelAuteur.getId());
            if (auteurCharge == null || !auteurCharge.getNom().equals("Dupont") || !auteurCharge.getPrenom().equals("Jean")) {
                throw new AssertionError("Échec: l'auteur inséré n'a pas été trouvé ou ses données ne correspondent pas.");
            }

            System.out.println("Succès: testInsertAuteur");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void testUpdateAuteur(AuteurDAO auteurDAO) {
        System.out.println("Test: testUpdateAuteur");
        try {
            Auteur auteur = new Auteur("Martin", "Paul", "1990-03-12");
            auteurDAO.save(auteur);

            // Mise à jour
            auteur.setNom("Martinez");
            auteur.setPrenom("Pablo");
            auteurDAO.save(auteur);

            // Vérifications
            Auteur auteurMisAJour = auteurDAO.getById(auteur.getId());
            if (auteurMisAJour == null || !auteurMisAJour.getNom().equals("Martinez") || !auteurMisAJour.getPrenom().equals("Pablo")) {
                throw new AssertionError("Échec: l'auteur n'a pas été correctement mis à jour.");
            }

            System.out.println("Succès: testUpdateAuteur");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void testDeleteAuteur(AuteurDAO auteurDAO) {
        System.out.println("Test: testDeleteAuteur");
        try {
            Auteur auteur = new Auteur("Rousseau", "Emile", "1975-10-22");
            auteurDAO.save(auteur);

            // Suppression
            auteurDAO.delete(auteur);

            // Vérification
            Auteur auteurSupprime = auteurDAO.getById(auteur.getId());
            if (auteurSupprime != null) {
                throw new AssertionError("Échec: l'auteur n'a pas été supprimé.");
            }

            System.out.println("Succès: testDeleteAuteur");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void testLoadAuteurWithSearchCriteria(AuteurDAO auteurDAO) {
        System.out.println("Test: testLoadAuteurWithSearchCriteria");
        try {
            // Insertion pour le test
            auteurDAO.save(new Auteur("Lemoine", "Claire", "1985-06-10"));
            auteurDAO.save(new Auteur("Lemoine", "Hugo", "1987-04-20"));

            // Recherche par nom
            RechercheAuteurVM recherche = new RechercheAuteurVM();
            recherche.setNom("Lemoine");

            ArrayList<Auteur> auteursTrouves = auteurDAO.load(recherche);

            // Vérifications
            if (auteursTrouves == null || auteursTrouves.size() != 2) {
                throw new AssertionError("Échec: le nombre d'auteurs trouvés ne correspond pas.");
            }

            boolean claireTrouvee = auteursTrouves.stream().anyMatch(a -> a.getPrenom().equals("Claire"));
            boolean hugoTrouve = auteursTrouves.stream().anyMatch(a -> a.getPrenom().equals("Hugo"));

            if (!claireTrouvee || !hugoTrouve) {
                throw new AssertionError("Échec: les auteurs attendus ne sont pas dans la liste.");
            }

            System.out.println("Succès: testLoadAuteurWithSearchCriteria");

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}

