package ServeurJava.Model.Tests;

import ServeurJava.Model.DAO.SujetDAO;
import ServeurJava.Model.Entites.Sujet;
import ServeurJava.Model.ViewModel.RechercheSujetVM;

import java.util.List;

public class TestSujetDAO {

    public static void main(String[] args) {
        SujetDAO sujetDAO = new SujetDAO();

        // Test de la méthode getSujets
        testGetSujets(sujetDAO);

        // Test de la méthode getById
        testGetById(sujetDAO);

        // Test de la méthode load avec critères
        testLoadWithCriteria(sujetDAO);

        // Test des méthodes save et delete
        testSaveAndDelete(sujetDAO);
    }

    public static void testGetSujets(SujetDAO sujetDAO) {
        System.out.println("Test getSujets...");
        List<Sujet> sujets = sujetDAO.getSujets();
        if (sujets != null) {
            System.out.println("La liste des sujets est correctement retournée.");
        } else {
            System.out.println("Erreur : La liste des sujets est nulle.");
        }
    }

    public static void testGetById(SujetDAO sujetDAO) {
        System.out.println("Test getById...");

        // Test sans sujet
        Sujet sujet = sujetDAO.getById(1);
        if (sujet == null) {
            System.out.println("Le sujet avec l'ID 1 n'existe pas, test passé.");
        } else {
            System.out.println("Erreur : Le sujet avec l'ID 1 existe alors qu'il ne devrait pas.");
        }

        // Ajouter un sujet pour le test
        Sujet nouveauSujet = new Sujet("Test Sujet");
        sujetDAO.save(nouveauSujet);

        // Récupérer le sujet après l'avoir ajouté
        Sujet sujetRecupere = sujetDAO.getById(nouveauSujet.getId());
        if (sujetRecupere != null && sujetRecupere.getId() == nouveauSujet.getId()) {
            System.out.println("Le sujet ajouté a bien été récupéré.");
        } else {
            System.out.println("Erreur : Le sujet ajouté n'a pas été récupéré correctement.");
        }
    }

    public static void testLoadWithCriteria(SujetDAO sujetDAO) {
        System.out.println("Test load avec critères...");

        RechercheSujetVM rechercheSujetVM = new RechercheSujetVM();
        rechercheSujetVM.setNom("Test");

        List<Sujet> sujets = sujetDAO.load(rechercheSujetVM);
        if (!sujets.isEmpty()) {
            System.out.println("La recherche avec critère 'Test' a renvoyé des sujets.");
        } else {
            System.out.println("Erreur : La recherche avec critère 'Test' n'a pas renvoyé de sujets.");
        }

        // Test sans critère
        List<Sujet> sujetsSansCritere = sujetDAO.load();
        if (!sujetsSansCritere.isEmpty()) {
            System.out.println("La recherche sans critères a renvoyé des sujets.");
        } else {
            System.out.println("Erreur : La recherche sans critères n'a pas renvoyé de sujets.");
        }
    }

    public static void testSaveAndDelete(SujetDAO sujetDAO) {
        System.out.println("Test save et delete...");

        Sujet sujet = new Sujet("Sujet pour test");

        // Sauvegarder un nouveau sujet
        sujetDAO.save(sujet);
        if (sujet.getId() != -1) {
            System.out.println("Le sujet a été sauvegardé avec l'ID : " + sujet.getId());
        } else {
            System.out.println("Erreur : Le sujet n'a pas été sauvegardé.");
        }

        // Vérifier que le sujet est bien sauvegardé
        Sujet sujetRecupere = sujetDAO.getById(sujet.getId());
        if (sujetRecupere != null) {
            System.out.println("Le sujet sauvegardé a bien été récupéré.");
        } else {
            System.out.println("Erreur : Le sujet sauvegardé n'a pas été récupéré.");
        }

        // Supprimer le sujet
        sujetDAO.delete(sujet);
        Sujet sujetSupprime = sujetDAO.getById(sujet.getId());
        if (sujetSupprime == null) {
            System.out.println("Le sujet a bien été supprimé.");
        } else {
            System.out.println("Erreur : Le sujet n'a pas été supprimé.");
        }
    }
}

