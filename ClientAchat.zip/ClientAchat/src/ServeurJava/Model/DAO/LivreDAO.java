package ServeurJava.Model.DAO;

import ServeurJava.Model.Entites.Livre;
import ServeurJava.Model.ViewModel.RechercheLivreVM;
import ServeurJava.Model.Base_De_Données.ConnexionBD;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class LivreDAO {
    private final ConnexionBD connexionBD;

    public LivreDAO(ConnexionBD connexionBD) {
        this.connexionBD = connexionBD;
    }

    public List<Livre> chargerLivres(RechercheLivreVM recherche) throws SQLException {
        List<Livre> livres = new ArrayList<>();

        String sql = "SELECT books.id, books.title, books.isbn, books.page_count, books.stock_quantity, books.price, " +
                "books.publish_year, authors.last_name AS author_name, subjects.name AS subject_name " +
                "FROM books " +
                "INNER JOIN authors ON books.author_id = authors.id " +
                "INNER JOIN subjects ON books.subject_id = subjects.id";

        if (recherche != null) {
            StringBuilder where = new StringBuilder(" WHERE 1=1 ");
            if (recherche.getId() != null) where.append("AND books.id = ? ");
            if (recherche.getNomAuteur() != null) where.append("AND authors.last_name LIKE ? ");
            if (recherche.getNomSujet() != null) where.append("AND subjects.name LIKE ? ");
            if (recherche.getTitre() != null) where.append("AND books.title LIKE ? ");
            if (recherche.getIsbn() != null) where.append("AND books.isbn LIKE ? ");
            if (recherche.getAnneePublication() != null) where.append("AND books.publish_year = ? ");
            sql += where;
        }

        try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql)) {
            if (recherche != null) {
                int index = 1;
                if (recherche.getId() != null) stmt.setInt(index++, recherche.getId());
                if (recherche.getNomAuteur() != null) stmt.setString(index++, "%" + recherche.getNomAuteur() + "%");
                if (recherche.getNomSujet() != null) stmt.setString(index++, "%" + recherche.getNomSujet() + "%");
                if (recherche.getTitre() != null) stmt.setString(index++, "%" + recherche.getTitre() + "%");
                if (recherche.getIsbn() != null) stmt.setString(index++, "%" + recherche.getIsbn() + "%");
                if (recherche.getAnneePublication() != null) stmt.setInt(index++, recherche.getAnneePublication());
            }

            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    Livre livre = new Livre();
                    livre.setId(rs.getInt("id"));
                    livre.setTitre(rs.getString("title"));
                    livre.setISBN(rs.getString("isbn"));
                    livre.setNombrePages(rs.getInt("page_count"));
                    livre.setQuantite(rs.getInt("stock_quantity"));
                    livre.setPrix(rs.getFloat("price"));
                    livre.setAnneePublication(rs.getInt("publish_year"));
                    livre.setNomAuteur(rs.getString("author_name"));
                    livre.setNomSujet(rs.getString("subject_name"));

                    livres.add(livre);
                }
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return livres;
    }

    public void sauvegarder(Livre livre) throws SQLException {
        if (livre == null) return;

        String sql;
        if (livre.getId() != null) {
            sql = "UPDATE books SET stock_quantity = ? WHERE id = ?";
        } else {
            sql = "INSERT INTO books (title, isbn, page_count, stock_quantity, price, publish_year, author_id, subject_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        }

        try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql))
        {
            if (livre.getId() != null)
            {
                stmt.setInt(1, livre.getQuantite());
                stmt.setInt(2, livre.getId());
            } else {
                stmt.setString(1, livre.getTitre());
                stmt.setString(2, livre.getISBN());
                stmt.setInt(3, livre.getNombrePages());
                stmt.setInt(4, livre.getQuantite());
                stmt.setFloat(5, livre.getPrix());
                stmt.setInt(6, livre.getAnneePublication());
                stmt.setInt(7, Integer.parseInt(livre.getNomAuteur())); // Corriger si besoin
                stmt.setInt(8, Integer.parseInt(livre.getNomSujet())); // Corriger si besoin
            }
            stmt.executeUpdate();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
