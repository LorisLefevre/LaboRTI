package ServeurJava.Model.DAO;

import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.Entites.Client;
import ServeurJava.Model.ViewModel.RechercheClientVM;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class ClientDAO
{

    private final ConnexionBD connexionBD;

    public ClientDAO(ConnexionBD connexionBD)
    {
        this.connexionBD = connexionBD;
    }

    public ArrayList<Client> loadClient(RechercheClientVM searchCriteria) throws SQLException {

        ArrayList<Client> clients = new ArrayList<>();

        String sql = "SELECT * FROM clients";

        if (searchCriteria != null)
        {
            StringBuilder where = new StringBuilder(" WHERE 1=1 ");
            if (searchCriteria.getId() != null)
            {
                where.append("AND clients.id = ? ");
            }
            if (searchCriteria.getNom() != null)
            {
                where.append("AND clients.nom LIKE ? ");
            }
            if (searchCriteria.getPrenom() != null)
            {
                where.append("AND clients.prenom LIKE ? ");
            }
            sql += where.toString();
        }

        try (Connection connection = connexionBD.getConnexion().connection;
             PreparedStatement stmt = connection.prepareStatement(sql))
        {
            if (searchCriteria != null)
            {
                int i = 0;
                if (searchCriteria.getId() != null)
                {
                    i++;
                    stmt.setInt(i, searchCriteria.getId());
                }
                if (searchCriteria.getNom() != null)
                {
                    i++;
                    stmt.setString(i, "%" + searchCriteria.getNom() + "%");
                }
                if (searchCriteria.getPrenom() != null)
                {
                    i++;
                    stmt.setString(i, "%" + searchCriteria.getPrenom() + "%");
                }
            }

            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    Client client = new Client();
                    client.setId(rs.getInt("id"));
                    client.setNom(rs.getString("nom"));
                    client.setPrenom(rs.getString("prenom"));
                    clients.add(client);
                }
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return clients;
    }

    public void sauvegarder(Client client) throws Exception
    {

        if (client == null)
        {
            throw new IllegalArgumentException("Le client ne peut pas être null");
        }

        if (client.getNom() == null || client.getPrenom() == null) {
            throw new Exception("Il manque le nom et/ou le prénom");
        }

        ArrayList<Client> existingClients = loadClient(
                new RechercheClientVM(null, client.getNom(), client.getPrenom()));
        if (!existingClients.isEmpty())
        {
            throw new Exception("Le client existe déjà");
        }

        String sql = "INSERT INTO clients (nom, prenom) VALUES (?, ?)";

        try (Connection connection = connexionBD.getConnexion().connection;
             PreparedStatement stmt = connection.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS))
        {

            stmt.setString(1, client.getNom());
            stmt.setString(2, client.getPrenom());
            stmt.executeUpdate();

            try (ResultSet rs = stmt.getGeneratedKeys())
            {
                if (rs.next())
                {
                    client.setId(rs.getInt(1));
                }
            }
        }
    }
}
