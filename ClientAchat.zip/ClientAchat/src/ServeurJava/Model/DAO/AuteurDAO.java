package ServeurJava.Model.DAO;

import ServeurJava.Model.Entites.Auteur;
import ServeurJava.Model.ViewModel.RechercheAuteurVM;
import ServeurJava.Model.Base_De_Données.ConnexionBD;

import java.sql.*;
import java.util.ArrayList;

public class AuteurDAO {
    private final Connection connection;
    private final ArrayList<Auteur> auteurs;

    public AuteurDAO() throws ClassNotFoundException, SQLException {
        this.connection = ConnexionBD.getInstance().connection;
        this.auteurs = new ArrayList<>();
    }

    public ArrayList<Auteur> getAuteurs() {
        return auteurs;
    }

    public Auteur getById(int id)
    {
        return auteurs.stream().filter(a -> a.getId() == id).findFirst().orElse(null);
    }

    public ArrayList<Auteur> load() {
        return this.load(null);
    }

    public ArrayList<Auteur> load(RechercheAuteurVM recherche) {
        try {
            String query = "SELECT id, nom, prenom, date_naissance FROM authors ";
            if (recherche != null) {
                query += "WHERE 1=1 ";
                if (recherche.getId() != null) query += "AND id = ? ";
                if (recherche.getNom() != null) query += "AND nom LIKE ? ";
                if (recherche.getPrenom() != null) query += "AND prenom LIKE ? ";
                query += "ORDER BY nom";
            }

            PreparedStatement prepStat = connection.prepareStatement(query);
            if (recherche != null) {
                int paramIndex = 0;
                if (recherche.getId() != null) prepStat.setInt(++paramIndex, recherche.getId());
                if (recherche.getNom() != null) prepStat.setString(++paramIndex, "%" + recherche.getNom() + "%");
                if (recherche.getPrenom() != null) prepStat.setString(++paramIndex, "%" + recherche.getPrenom() + "%");
            }

            ResultSet resultSet = prepStat.executeQuery();
            auteurs.clear();

            while (resultSet.next()) {
                Auteur auteur = new Auteur(
                        resultSet.getInt("id"),
                        resultSet.getString("nom"),
                        resultSet.getString("prenom"),
                        resultSet.getString("date_naissance")
                );
                auteurs.add(auteur);
            }

            resultSet.close();
            prepStat.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return auteurs;
    }

    public void save(Auteur auteur) {
        try {
            if (auteur.getId() != null && auteur.getId() > 0) {
                // Mise à jour
                String query = "UPDATE authors SET last_name = ?, first_name = ?, birth_date = ? WHERE id = ?";
                try (PreparedStatement prepStat = connection.prepareStatement(query)) {
                    prepStat.setString(1, auteur.getNom());
                    prepStat.setString(2, auteur.getPrenom());
                    prepStat.setString(3, auteur.getDateNaissance());
                    prepStat.setInt(4, auteur.getId());
                    prepStat.executeUpdate();
                }
            } else {
                // Insertion
                String query = "INSERT INTO authors (last_name, first_name, birth_date) VALUES (?, ?, ?)";
                try (PreparedStatement prepStat = connection.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {
                    prepStat.setString(1, auteur.getNom());
                    prepStat.setString(2, auteur.getPrenom());
                    prepStat.setString(3, auteur.getDateNaissance());
                    prepStat.executeUpdate();

                    // Récupérer l'ID généré
                    try (ResultSet resultSet = prepStat.getGeneratedKeys()) {
                        if (resultSet.next()) {
                            auteur.setId(resultSet.getInt(1));
                        }
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void delete(Auteur auteur)
    {
        if (auteur != null) {
            delete(auteur.getId());
        }
    }

    public void delete(int id) {
        try {
            String query = "DELETE FROM authors WHERE id = ?";
            PreparedStatement prepStat = connection.prepareStatement(query);
            prepStat.setInt(1, id);
            prepStat.executeUpdate();
            prepStat.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
