package ServeurJava.Model.DAO;

import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.Entites.CaddyItem;
import ServeurJava.Model.ViewModel.RechercheCaddyItemVM;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CaddyItemDAO {

    private final ConnexionBD connexionBD;

    public CaddyItemDAO(ConnexionBD connexionBD)
    {
        this.connexionBD = connexionBD;
    }

    public List<CaddyItem> charger(RechercheCaddyItemVM rechercheVM) throws SQLException
    {
        List<CaddyItem> caddyItems = new ArrayList<>();
        String sql = "SELECT * FROM caddy_items";

        if (rechercheVM != null && rechercheVM.getIdCaddy() != null)
        {
            sql += " WHERE id = ?";
        }

        try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql))
        {
            if (rechercheVM != null && rechercheVM.getIdCaddy() != null)
            {
                stmt.setInt(1, rechercheVM.getIdCaddy());
            }

            try (ResultSet rs = stmt.executeQuery())
            {
                while (rs.next())
                {
                    CaddyItem caddyItem = new CaddyItem(
                            rs.getInt("id"),
                            rs.getInt("caddyId"),
                            rs.getInt("bookId"),
                            rs.getInt("quantity")
                    );
                    caddyItems.add(caddyItem);
                }
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }

        return caddyItems;
    }

    public void sauvegarder(CaddyItem caddyItem) throws SQLException
    {
        if (caddyItem == null) return;

        String sql;
        if (caddyItem.getId() != null) { // UPDATE
            sql = "UPDATE caddy_items SET caddyId = ?, bookId = ?, quantity = ? WHERE id = ?";
            try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql))
            {
                stmt.setInt(1, caddyItem.getCaddyId());
                stmt.setInt(2, caddyItem.getBookId());
                stmt.setInt(3, caddyItem.getQuantity());
                stmt.setInt(4, caddyItem.getId());
                stmt.executeUpdate();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            sql = "INSERT INTO caddy_items (caddyId, bookId, quantity) VALUES (?, ?, ?)";
            try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                stmt.setInt(1, caddyItem.getCaddyId());
                stmt.setInt(2, caddyItem.getBookId());
                stmt.setInt(3, caddyItem.getQuantity());
                stmt.executeUpdate();

                try (ResultSet rs = stmt.getGeneratedKeys())
                {
                    if (rs.next())
                    {
                        caddyItem.setId(rs.getInt(1));
                    }
                }
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public void supprimer(CaddyItem caddyItem) throws SQLException
    {
        if (caddyItem != null && caddyItem.getId() != null)
        {
            supprimer(caddyItem.getId());
        }
    }

    public void supprimer(Integer id) throws SQLException
    {
        if (id == null) return;

        String sql = "DELETE FROM caddy_items WHERE id = ?";
        try (PreparedStatement stmt = connexionBD.getConnexion().connection.prepareStatement(sql))
        {
            stmt.setInt(1, id);
            stmt.executeUpdate();
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}
