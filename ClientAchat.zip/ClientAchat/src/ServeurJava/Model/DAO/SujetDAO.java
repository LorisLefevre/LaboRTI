package ServeurJava.Model.DAO;
import ServeurJava.Model.Entites.Sujet;
import ServeurJava.Model.ViewModel.RechercheSujetVM;
import ServeurJava.Model.Base_De_Données.ConnexionBD;

import java.sql.*;
import java.util.ArrayList;

public class SujetDAO
{
    private final Connection connection;
    private final ArrayList<Sujet> sujets;

    public SujetDAO()
    {
        try
        {
            connection = ConnexionBD.getInstance().getConnexion().connection;
            sujets = new ArrayList<>();
        }
        catch (ClassNotFoundException | SQLException e)
        {
            throw new RuntimeException(e);
        }
    }

    public ArrayList<Sujet> getSujets()
    {
        return sujets;
    }

    public Sujet getById(Integer id)
    {
        for (Sujet sujet : sujets)
        {
            if (sujet.getId() == id)
            {
                return sujet;
            }
        }
        return null;
    }

    public ArrayList<Sujet> load(RechercheSujetVM rechercheSujetVM) {
        try {
            String query = "SELECT " +
                    "sujets.id, " +
                    "sujets.nom " +
                    "FROM subjects ";

            if (rechercheSujetVM != null) {
                String where = "WHERE 1=1 ";

                if (rechercheSujetVM.getId() != null) {
                    where += "AND subjects.id = ? ";
                }

                if (rechercheSujetVM.getNom() != null) {
                    where += "AND subjects.name LIKE ? ";
                }

                query += where + "ORDER BY subjects.name";
            }

            PreparedStatement prepStat = connection.prepareStatement(query);

            if (rechercheSujetVM != null) {
                int paramNumber = 0;

                if (rechercheSujetVM.getId() != null) {
                    paramNumber++;
                    prepStat.setInt(paramNumber, rechercheSujetVM.getId());
                }

                if (rechercheSujetVM.getNom() != null) {
                    paramNumber++;
                    prepStat.setString(paramNumber, "%" + rechercheSujetVM.getNom() + "%");
                }
            }

            ResultSet rs = prepStat.executeQuery();

            sujets.clear();

            while (rs.next()) {
                Sujet sujet = new Sujet(rs.getInt("id"), rs.getString("nom"));
                sujets.add(sujet);
            }

            rs.close();
            prepStat.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

        return sujets;
    }

    public void save(Sujet sujet) {
        try {
            String query;

            if (sujet != null) {
                if (sujet.getId() != -1)
                { // Update
                    if (sujet.getNom() == null) return;

                    query = "UPDATE subjects SET name = ? WHERE id = ?";

                    PreparedStatement prepStat = connection.prepareStatement(query);
                    prepStat.setString(1, sujet.getNom());
                    prepStat.setInt(2, sujet.getId());
                    prepStat.executeUpdate();
                    prepStat.close();
                } else { // Insert
                    if (sujet.getNom() == null) return;

                    query = "INSERT INTO subjects (name) VALUES (?)";

                    PreparedStatement prepStat = connection.prepareStatement(query, PreparedStatement.RETURN_GENERATED_KEYS);
                    prepStat.setString(1, sujet.getNom());
                    prepStat.executeUpdate();

                    ResultSet rs = prepStat.getGeneratedKeys();
                    if (rs.next()) {
                        sujet.setId(rs.getInt(1));
                    }
                    rs.close();
                    prepStat.close();
                }
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void delete(Sujet sujet) {
        if (sujet != null && sujet.getId() != -1) {
            this.delete(sujet.getId());
        }
    }

    public void delete(Integer id) {
        if (id != null) {
            try {
                String query = "DELETE FROM subjects WHERE id = ?";
                PreparedStatement prepStat = connection.prepareStatement(query);
                prepStat.setInt(1, id);
                prepStat.executeUpdate();
                prepStat.close();
            } catch (SQLException e) {
                throw new RuntimeException(e);
            }
        }
    }

    public ArrayList<Sujet> load() {
        return this.load(null);
    }
}
