package ServeurJava.Model.DAO;

import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.Entites.Caddy;
import ServeurJava.Model.ViewModel.RechercheCaddyVM;

import java.sql.*;
import java.util.ArrayList;

public class CaddyDAO
{

    private final ConnexionBD connectDB;


    public CaddyDAO(ConnexionBD connectDB)
    {
        this.connectDB = connectDB;
    }


    public ArrayList<Caddy> load(RechercheCaddyVM rechercheVM) throws SQLException
    {
        String sql = "SELECT * FROM caddies";
        if (rechercheVM != null && rechercheVM.getId() != null)
        {
            sql += " WHERE id = ?";
        }

        try (Connection connection = connectDB.getConnexion().connection;
             PreparedStatement stmt = connection.prepareStatement(sql))
        {

            if (rechercheVM != null && rechercheVM.getId() != null)
            {
                stmt.setInt(1, rechercheVM.getId());
            }

            try (ResultSet rs = stmt.executeQuery())
        {
                ArrayList<Caddy> caddyList = new ArrayList<>();

                while (rs.next())
                {
                    Caddy caddy = new Caddy(
                            rs.getInt("id"),
                            rs.getInt("clientId"),
                            rs.getDate("date").toLocalDate(),
                            rs.getDouble("amount"),
                            rs.getBoolean("isPayed")
                    );
                    caddyList.add(caddy);
                }

                return caddyList;
            }
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public void save(Caddy caddy) throws SQLException
    {
        if (caddy == null)
        {
            throw new IllegalArgumentException("Le caddy ne peut pas être null");
        }

        String sql;
        if (caddy.getId() != null)
        {
            sql = "UPDATE caddies SET clientId = ?, date = ?, amount = ?, isPayed = ? WHERE id = ?";
            try (Connection connection = connectDB.getConnexion().connection;
                 PreparedStatement stmt = connection.prepareStatement(sql)) {

                stmt.setInt(1, caddy.getIdClient());
                stmt.setDate(2, Date.valueOf(caddy.getDate()));
                stmt.setDouble(3, caddy.getMontant());
                stmt.setBoolean(4, caddy.getPaye());
                stmt.setInt(5, caddy.getId());
                stmt.executeUpdate();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            sql = "INSERT INTO caddies (clientId, date, amount, isPayed) VALUES (?, ?, ?, ?)";
            try (Connection connection = connectDB.getConnexion().connection;
                 PreparedStatement stmt = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS))
            {

                stmt.setInt(1, caddy.getIdClient());
                stmt.setDate(2, Date.valueOf(caddy.getDate()));
                stmt.setDouble(3, caddy.getMontant());
                stmt.setBoolean(4, caddy.getPaye());
                stmt.executeUpdate();

                try (ResultSet rs = stmt.getGeneratedKeys())
                {
                    if (rs.next()) {
                        caddy.setId(rs.getInt(1));
                    }
                }
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
    }


    public void delete(Caddy caddy) throws SQLException
    {
        if (caddy != null && caddy.getId() != null)
        {
            delete(caddy.getId());
        }
    }


    public void delete(Integer id) throws SQLException
    {
        if (id != null)
        {
            String sql = "DELETE FROM caddies WHERE id = ?";
            try (Connection connection = connectDB.getConnexion().connection;
                 PreparedStatement stmt = connection.prepareStatement(sql))
            {

                stmt.setInt(1, id);
                stmt.executeUpdate();
            } catch (ClassNotFoundException e) {
                throw new RuntimeException(e);
            }
        }
        else
        {
            throw new IllegalArgumentException("L'identifiant du caddy ne peut pas être null");
        }
    }
}
