package ServeurJava.Model.ViewModel;

import java.io.Serializable;

public class RechercheCaddyItemVM implements Serializable
{
    private Integer idCaddy;
    private Integer idLivre;

    public Integer getIdCaddy()
    {
        return idCaddy;
    }

    public void setIdCaddy(Integer idCaddy)
    {
        this.idCaddy = idCaddy;
    }

    public Integer getIdLivre()
    {
        return idLivre;
    }

    public void setIdLivre(Integer idLivre)
    {
        this.idLivre = idLivre;
    }

    public RechercheCaddyItemVM()
    {
        this.idCaddy = null;
        this.idLivre = null;
    }

    public RechercheCaddyItemVM(Integer idCaddy, Integer idLivre)
    {
        this.idCaddy = idCaddy;
        this.idLivre = idLivre;
    }
}
