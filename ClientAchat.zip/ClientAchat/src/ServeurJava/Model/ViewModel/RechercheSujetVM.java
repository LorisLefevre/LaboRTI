package ServeurJava.Model.ViewModel;

public class RechercheSujetVM
{
    private Integer id;
    private String nom;

    public Integer getId()
    {
        return id;
    }

    public void setId(Integer id)
    {
        this.id = id;
    }

    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public RechercheSujetVM()
    {
        this.id = null;
        this.nom = null;
    }

    public RechercheSujetVM(Integer id, String nom)
    {
        this.id = id;
        this.nom = nom;
    }
}
