package ServeurJava.Model.ViewModel;

import java.io.Serializable;

public class RechercheLivreVM implements Serializable
{
    private Integer id;
    private String nomAuteur;
    private String nomSujet;
    private String titre;
    private String isbn;
    private Integer anneePublication;

    public Integer getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public String getNomAuteur()
    {
        return nomAuteur;
    }

    public void setNomAuteur(String nomAuteur)
    {
        this.nomAuteur = nomAuteur;
    }

    public String getNomSujet()
    {
        return nomSujet;
    }

    public void setNomSujet(String nomSujet)
    {
        this.nomSujet = nomSujet;
    }

    public String getTitre()
    {
        return titre;
    }

    public void setTitre(String titre)
    {
        this.titre = titre;
    }

    public String getIsbn()
    {
        return isbn;
    }

    public void setIsbn(String isbn)
    {
        this.isbn = isbn;
    }

    public Integer getAnneePublication()
    {
        return anneePublication;
    }

    public void setAnneePublication(int anneePublication)
    {
        this.anneePublication = anneePublication;
    }

    public RechercheLivreVM()
    {
        this.id = null;
        this.nomAuteur = null;
        this.nomSujet = null;
        this.titre = null;
        this.isbn = null;
        this.anneePublication = null;
    }

    public RechercheLivreVM(Integer id, String nomAuteur, String nomSujet, String titre, String isbn, Integer anneePublication)
    {
        this.id = id;
        this.nomAuteur = nomAuteur;
        this.nomSujet = nomSujet;
        this.titre = titre;
        this.isbn = isbn;
        this.anneePublication = anneePublication;
    }

}
