package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;

public class RecupererArticleRequete implements Requete
{
    public RecupererArticleRequete()
    {

    }
}
