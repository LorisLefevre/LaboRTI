package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;

public class LogoutRequete implements Requete
{
    public LogoutRequete()
    {

    }
}
