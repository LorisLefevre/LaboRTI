package ServeurJava.Model.Base_De_Données.Requetes;

public class RecupererPrixArticleRequete
{

}
