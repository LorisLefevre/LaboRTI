package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;

public class SupprimerArticleRequete implements Requete
{
    private Integer idLivre;
    private Integer quantite;

    public Integer getIdLivre()
    {
        return idLivre;
    }

    public void setIdLivre(Integer idLivre)
    {
        this.idLivre = idLivre;
    }

    public Integer getQuantite()
    {
        return quantite;
    }

    public void setQuantite(Integer quantite)
    {
        this.quantite = quantite;
    }

    public SupprimerArticleRequete(Integer idLivre, Integer quantite)
    {
        this.idLivre = idLivre;
        this.quantite = quantite;
    }
}
