package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;

public class EffacerPanierRequete implements Requete
{
    private Integer idClient;

    public Integer getIdClient()
    {
        return idClient;
    }

    public void setIdClient(Integer idClient)
    {
        this.idClient = idClient;
    }

    public EffacerPanierRequete(Integer idClient)
    {
        this.idClient = idClient;
    }
}
