package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;

public class ClientRequete implements Requete
{
    private String nom;
    private String prenom;
    private Boolean estNouveau;

    public String getNom()
    {
        return nom;
    }

    public void setNom(String nom)
    {
        this.nom = nom;
    }

    public String getPrenom()
    {
        return prenom;
    }

    public void setPrenom(String prenom)
    {
        this.prenom = prenom;
    }

    public Boolean getEstNouveau()
    {
        return estNouveau;
    }

    public void setEstNouveau(Boolean estNouveau)
    {
        this.estNouveau = estNouveau;
    }

    public ClientRequete(String nom, String prenom, Boolean estNouveau)
    {
        this.nom = nom;
        this.prenom = prenom;
        this.estNouveau = estNouveau;
    }
}
