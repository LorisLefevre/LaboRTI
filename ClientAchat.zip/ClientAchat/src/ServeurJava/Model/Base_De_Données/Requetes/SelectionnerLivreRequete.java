package ServeurJava.Model.Base_De_Données.Requetes;

import ServeurJava.Model.Base_De_Données.Requete;
import ServeurJava.Model.ViewModel.RechercheLivreVM;

public class SelectionnerLivreRequete implements Requete
{
    private RechercheLivreVM rechercheLivreVM;

    public RechercheLivreVM getRechercheLivreVM()
    {
        return rechercheLivreVM;
    }

    public void setRechercheLivreVM(RechercheLivreVM rechercheLivreVM)
    {
        this.rechercheLivreVM = rechercheLivreVM;
    }

    public SelectionnerLivreRequete(RechercheLivreVM rechercheLivreVM)
    {
        this.rechercheLivreVM = rechercheLivreVM;
    }
}
