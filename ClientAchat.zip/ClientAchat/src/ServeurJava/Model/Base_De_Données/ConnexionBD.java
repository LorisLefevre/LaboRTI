package ServeurJava.Model.Base_De_Données;

import java.sql.*;
import java.util.Hashtable;

public class ConnexionBD {
    public Connection connection = null;

    private static ConnexionBD instance;

    public static ConnexionBD getInstance() throws ClassNotFoundException, SQLException {
        if (instance == null) {
            instance = new ConnexionBD("127.0.0.1");
        }
        return instance;
    }

    public ConnexionBD getConnexion() throws ClassNotFoundException, SQLException {
        if (instance == null) {
            instance = new ConnexionBD("127.0.0.1");
        }
        return instance;
    }

    public ConnexionBD(String IP) throws ClassNotFoundException, SQLException
    {
        try {
            Class<?> mysqlDriver = Class.forName("com.mysql.cj.jdbc.Driver");
            System.out.println("\nDriver MySQL obtenu\n");

            System.out.printf("Tentative de connexion à la base de données MySQL avec l'IP : %s\n", IP);
            connection = DriverManager.getConnection("jdbc:mysql://" + IP + ":3306/Loris_Base", "root", "LorisRace02.");
            System.out.println("\nConnexion à la base de données MySQL réussie");
        } catch (ClassNotFoundException e) {
            System.err.println("Erreur : Le driver MySQL n'a pas été trouvé.");
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (SQLException e) {
            System.err.printf("Erreur de connexion à la base de données MySQL : %s\n", e.getMessage());
            System.err.printf("Code d'erreur SQL : %d\n", e.getErrorCode());
            System.err.printf("État SQL : %s\n", e.getSQLState());
            e.printStackTrace();

            try {
                System.out.println("\nTentative de connexion à la base de données H2...");
                Class<?> h2Driver = Class.forName("org.h2.Driver");
                System.out.println("Driver H2 obtenu");

                connection = DriverManager.getConnection("jdbc:h2:./PourStudent", "sa", "");
                System.out.println("\nConnexion à la base de données H2 réussie");
            } catch (ClassNotFoundException h2Exception) {
                System.err.println("Erreur : Le driver H2 n'a pas été trouvé.");
                h2Exception.printStackTrace();
                throw new RuntimeException(h2Exception);
            } catch (SQLException h2Exception) {
                System.err.println("Erreur de connexion à la base de données H2 :");
                h2Exception.printStackTrace();
                throw new RuntimeException(h2Exception);
            }
        }
    }

    public synchronized ResultSet getTuple(String SQL) throws SQLException {
        Statement statement = connection.createStatement();
        return statement.executeQuery(SQL);
    }

    public synchronized int ExecuterUpdate(String SQL) throws SQLException {
        Statement statement = connection.createStatement();
        return statement.executeUpdate(SQL);
    }

    public synchronized void Close() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            try {
                connection.close();
                System.out.println("\nConnexion à la base de donnée fermée\n");
            } catch (SQLException e) {
                System.out.println("\nErreur lors de la fermeture de la connexion à la base de données : " + e);
            }
        }


    }

    public static void main(String[] args)
    {
        try {
            // Test de la connexion MySQL en utilisant l'IP "localhost" (ou l'adresse IP du serveur MySQL)
            ConnexionBD connexion = ConnexionBD.getInstance();

            // Exécuter une requête simple pour tester la connexion
            String query = "SELECT * FROM employees";  // Remplacez 'some_table' par une table existante dans votre base de données
            ResultSet resultSet = connexion.getTuple(query);

            // Afficher les résultats de la requête (si il y en a)
            while (resultSet.next()) {
                // Exemple d'affichage des résultats, remplacez 'column1', 'column2' par les noms réels de vos colonnes
                System.out.println("Column 1: " + resultSet.getString("login"));
                System.out.println("Column 2: " + resultSet.getString("password"));
            }

            // Exemple d'update (si nécessaire)
            String updateQuery = "INSERT into employees(login, password) VALUES ('Marcel', '1234');";
            int rowsAffected = connexion.ExecuterUpdate(updateQuery);
            System.out.println("Rows affected: " + rowsAffected);

            // Fermer la connexion après le test
            connexion.Close();

        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
        }
    }
}
