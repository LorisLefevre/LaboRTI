package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;
import ServeurJava.Model.Entites.CaddyItem;

import java.util.ArrayList;

public class RecupererArticleReponse implements Reponse
{
    private ArrayList<CaddyItem> article;

    public ArrayList<CaddyItem> getArticle()
    {
        return article;
    }

    public void setArticle(ArrayList<CaddyItem> article)
    {
        this.article = article;
    }

    public RecupererArticleReponse(ArrayList<CaddyItem> article)
    {
        this.article = article;
    }
}
