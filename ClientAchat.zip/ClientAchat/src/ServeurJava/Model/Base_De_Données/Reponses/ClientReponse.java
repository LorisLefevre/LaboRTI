package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;

public class ClientReponse implements Reponse
{
    private Integer idClient;

    public Integer getIdClient()
    {
        return idClient;
    }

    public void setIdClient(Integer idClient)
    {
        this.idClient = idClient;
    }

    public ClientReponse(Integer idClient)
    {
        this.idClient = idClient;
    }
}
