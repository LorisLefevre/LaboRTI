package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;

public class SupprimerArticleReponse implements Reponse
{
    public Boolean reponse;

    public Boolean getReponse()
    {
        return reponse;
    }

    public void setReponse(Boolean reponse)
    {
        this.reponse = reponse;
    }

    public SupprimerArticleReponse(Boolean reponse)
    {
        this.reponse = reponse;
    }
}
