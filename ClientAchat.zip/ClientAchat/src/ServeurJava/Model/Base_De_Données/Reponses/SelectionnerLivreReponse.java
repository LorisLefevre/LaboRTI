package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;
import ServeurJava.Model.Entites.Livre;

import java.util.ArrayList;

public class SelectionnerLivreReponse implements Reponse
{
    private ArrayList<Livre> livres;

    public ArrayList<Livre> getLivres()
    {
        return livres;
    }

    public void setLivres(ArrayList<Livre> livres)
    {
        this.livres = livres;
    }

    public SelectionnerLivreReponse(ArrayList<Livre> livres)
    {
        this.livres = livres;
    }
}
