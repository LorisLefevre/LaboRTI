package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;

public class MessageErreur implements Reponse
{
    private String message;

    public String getMessage()
    {
        return message;
    }

    public void setMessage(String message)
    {
        this.message = message;
    }

    public MessageErreur(String message)
    {
        this.message = message;
    }
}
