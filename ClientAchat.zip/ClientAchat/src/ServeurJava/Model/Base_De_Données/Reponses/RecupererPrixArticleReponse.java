package ServeurJava.Model.Base_De_Données.Reponses;

import ServeurJava.Model.Base_De_Données.Reponse;

public class RecupererPrixArticleReponse implements Reponse
{
    private Double prixArticle;

    public Double getPrixArticle()
    {
        return prixArticle;
    }

    public void setPrixArticle(Double prixArticle)
    {
        this.prixArticle = prixArticle;
    }

    public RecupererPrixArticleReponse(Double prixArticle)
    {
        this.prixArticle = prixArticle;
    }
}
