package ServeurJava.Model.Base_De_Données;

import java.io.Serializable;

public interface Reponse extends Serializable
{

}
