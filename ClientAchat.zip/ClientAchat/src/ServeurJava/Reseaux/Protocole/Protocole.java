package ServeurJava.Reseaux.Protocole;

import ServeurJava.Exception.TerminerConnexionException;
import ServeurJava.Model.Base_De_Données.Reponse;
import ServeurJava.Model.Base_De_Données.Requete;

import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;

public interface Protocole
{
    String RecupererNom();
    Reponse TraitementRequete(Requete requete, Socket socket) throws IOException, SQLException, TerminerConnexionException;
}
