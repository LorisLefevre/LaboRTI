package ServeurJava.Reseaux.Protocole;

import ServeurJava.Exception.TerminerConnexionException;
import ServeurJava.Model.Base_De_Données.ConnexionBD;
import ServeurJava.Model.Base_De_Données.Reponse;
import ServeurJava.Model.Base_De_Données.Reponses.*;
import ServeurJava.Model.Base_De_Données.Requete;
import ServeurJava.Model.Base_De_Données.Requetes.*;
import ServeurJava.Model.DAO.CaddyDAO;
import ServeurJava.Model.DAO.CaddyItemDAO;
import ServeurJava.Model.DAO.ClientDAO;
import ServeurJava.Model.DAO.LivreDAO;
import ServeurJava.Model.Entites.Caddy;
import ServeurJava.Model.Entites.CaddyItem;
import ServeurJava.Model.Entites.Client;
import ServeurJava.Model.Entites.Livre;
import ServeurJava.Model.ViewModel.RechercheCaddyItemVM;
import ServeurJava.Model.ViewModel.RechercheCaddyVM;
import ServeurJava.Model.ViewModel.RechercheClientVM;
import ServeurJava.Model.ViewModel.RechercheLivreVM;

import java.io.IOException;
import java.net.Socket;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

public class BSPP implements Protocole
{
    private final ConnexionBD connexionBD;
    private Caddy articleCourant;
    private Client clientCourant;

    public BSPP(ConnexionBD connexionBD)
    {
        this.connexionBD = connexionBD;
        this.articleCourant = null;
        this.clientCourant = null;
    }
    @Override
    public String RecupererNom()
    {
        return "BSPP";
    }

    @Override
    public synchronized Reponse TraitementRequete(Requete requete, Socket socket) throws IOException, SQLException, TerminerConnexionException
    {
        if(requete instanceof LogoutRequete)
        {
            throw new TerminerConnexionException(null);
        }

        if(requete instanceof ClientRequete)
        {
            try
            {
                ClientDAO clientDAO = new ClientDAO(connexionBD);
                ClientRequete clientRequete = (ClientRequete) requete;

                if(clientRequete.getEstNouveau())
                {
                    RechercheClientVM rechercheClientVM = new RechercheClientVM();
                    rechercheClientVM.setNom(rechercheClientVM.getNom());
                    rechercheClientVM.setPrenom(rechercheClientVM.getPrenom());

                    ArrayList<Client> clients = clientDAO.loadClient(rechercheClientVM);
                    if(clients.isEmpty())
                    {
                        clientCourant = new Client(null, clientRequete.getNom(), clientRequete.getPrenom());
                        clientDAO.sauvegarder(clientCourant);
                    }
                    else
                    {
                        throw new Exception("Le client existe déjà");
                    }
                }

                else
                {
                    RechercheClientVM rechercheClientVM = new RechercheClientVM();
                    rechercheClientVM.setNom(rechercheClientVM.getNom());
                    rechercheClientVM.setPrenom(rechercheClientVM.getPrenom());

                    ArrayList<Client> clients = clientDAO.loadClient(rechercheClientVM);
                    if(clients.isEmpty())
                    {
                        throw new Exception("Le client n'existe pas");
                    }

                    else
                    {
                        clientCourant = clients.getFirst();
                    }
                }

                return new ClientReponse(clientCourant.getId());
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }
        }

        if(requete instanceof SelectionnerLivreRequete selectionnerLivreRequete)
        {
            LivreDAO livreDAO = new LivreDAO(connexionBD);
            return new SelectionnerLivreReponse((ArrayList<Livre>) livreDAO.chargerLivres(selectionnerLivreRequete.getRechercheLivreVM()));
        }

        if(requete instanceof AjouterArticleRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    AjouterArticleRequete ajouterArticleRequete = (AjouterArticleRequete) requete;

                    if(articleCourant == null)
                    {
                        articleCourant = new Caddy(null, clientCourant.getId(), LocalDate.now(), 0.0, false);

                        CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                        caddyDAO.save(articleCourant);
                    }

                    CaddyItemDAO caddyItemDAO  = new CaddyItemDAO(connexionBD);
                    CaddyItem caddyItem = new CaddyItem(null, articleCourant.getId(), ajouterArticleRequete.getIdLivre(), ajouterArticleRequete.getQuantite());

                    LivreDAO livreDAO = new LivreDAO(connexionBD);
                    RechercheLivreVM rechercheLivreVM = new RechercheLivreVM();
                    rechercheLivreVM.setId(ajouterArticleRequete.getIdLivre());
                    ArrayList<Livre> bookArrayList = (ArrayList<Livre>) livreDAO.chargerLivres(rechercheLivreVM);

                    if(bookArrayList.getFirst().getQuantite() < ajouterArticleRequete.getQuantite()) {
                        return new AjouterArticleReponse(false);
                    }

                    int quantity = bookArrayList.getFirst().getQuantite();
                    quantity -= ajouterArticleRequete.getQuantite();
                    bookArrayList.getFirst().setQuantite(quantity);

                    double price = bookArrayList.getFirst().getPrix() * ajouterArticleRequete.getQuantite();
                    CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                    RechercheCaddyVM rechercheCaddyVM = new RechercheCaddyVM(this.articleCourant.getId());
                    ArrayList<Caddy> caddy = caddyDAO.load(rechercheCaddyVM);
                    price = price + caddy.getFirst().getMontant();
                    caddy.getFirst().setMontant(price);
                    caddyDAO.save(caddy.getFirst());

                    RechercheCaddyItemVM rechercheCaddyItemVM = new RechercheCaddyItemVM();
                    rechercheCaddyItemVM.setIdCaddy(articleCourant.getId());
                    rechercheCaddyItemVM.setIdLivre(bookArrayList.getFirst().getId());
                    ArrayList<CaddyItem> caddyItemArrayList = (ArrayList<CaddyItem>) caddyItemDAO.charger(rechercheCaddyItemVM);

                    if(!caddyItemArrayList.isEmpty()) {
                        caddyItem.setId(caddyItemArrayList.getFirst().getId());
                    }
                    caddyItemDAO.sauvegarder(caddyItem);
                    livreDAO.sauvegarder(bookArrayList.getFirst());

                    return new AjouterArticleReponse(true);


                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }

        }

        if(requete instanceof SupprimerArticleRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    SupprimerArticleRequete supprimerArticleRequete = (SupprimerArticleRequete) requete;

                    CaddyItemDAO caddyItemDAO = new CaddyItemDAO(connexionBD);
                    RechercheCaddyItemVM rechercheCaddyItemVM = new RechercheCaddyItemVM();
                    rechercheCaddyItemVM.setIdCaddy(articleCourant.getId());
                    rechercheCaddyItemVM.setIdLivre(supprimerArticleRequete.getIdLivre());
                    ArrayList<CaddyItem> caddyItemArrayList = (ArrayList<CaddyItem>) caddyItemDAO.charger(rechercheCaddyItemVM);

                    if(caddyItemArrayList.isEmpty()) {
                        return new SupprimerArticleReponse(false);
                    }

                    if(supprimerArticleRequete.getQuantite() == null) {
                        caddyItemDAO.supprimer(caddyItemArrayList.getFirst().getId());
                        return new SupprimerArticleReponse(true);
                    }

                    int quantity = caddyItemArrayList.getFirst().getQuantity() - supprimerArticleRequete.getQuantite();
                    CaddyItem caddyItem = new CaddyItem(caddyItemArrayList.getFirst().getId(), articleCourant.getId(), supprimerArticleRequete.getIdLivre(), quantity);
                    if(quantity < 0) {
                        return new SupprimerArticleReponse(false);
                    }
                    else if(quantity == 0) {
                        caddyItemDAO.supprimer(caddyItem);
                    }
                    else
                    {
                        caddyItemDAO.sauvegarder(caddyItem);
                    }

                    LivreDAO livreDAO = new LivreDAO(connexionBD);
                    RechercheLivreVM rechercheLivreVM = new RechercheLivreVM();
                    rechercheLivreVM.setId(supprimerArticleRequete.getIdLivre());
                    ArrayList<Livre> livres = (ArrayList<Livre>) livreDAO.chargerLivres(rechercheLivreVM);
                    int newQuantityToAdd = livres.getFirst().getQuantite();
                    newQuantityToAdd += supprimerArticleRequete.getQuantite();
                    livres.getFirst().setQuantite(newQuantityToAdd);
                    livreDAO.sauvegarder(livres.getFirst());

                    double price = livres.getFirst().getPrix() * supprimerArticleRequete.getQuantite();
                    CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                    RechercheCaddyVM rechercheCaddyVM = new RechercheCaddyVM(this.articleCourant.getId());
                    ArrayList<Caddy> caddy = caddyDAO.load(rechercheCaddyVM);
                    price = caddy.getFirst().getMontant() - price;
                    caddy.getFirst().setMontant(price);
                    caddyDAO.save(caddy.getFirst());

                    return new SupprimerArticleReponse(true);
                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }
        }

        if(requete instanceof RecupererArticleRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    RechercheCaddyItemVM rechercheCaddyItemVM = new RechercheCaddyItemVM();
                    rechercheCaddyItemVM.setIdCaddy(articleCourant.getId());
                    CaddyItemDAO caddyItemDAO = new CaddyItemDAO(connexionBD);
                    ArrayList<CaddyItem> article = (ArrayList<CaddyItem>) caddyItemDAO.charger(rechercheCaddyItemVM);
                    return new RecupererArticleReponse(article);
                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }
        }

        if(requete instanceof RecupererPrixArticleRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                    ArrayList<Caddy> article = caddyDAO.load(new RechercheCaddyVM(articleCourant.getId()));
                    return new RecupererPrixArticleReponse(article.getFirst().getMontant());
                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }
        }

        if(requete instanceof EffacerPanierRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    CaddyItemDAO caddyItemDAO = new CaddyItemDAO(connexionBD);
                    RechercheCaddyItemVM rechercheCaddyItemVM = new RechercheCaddyItemVM();
                    rechercheCaddyItemVM.setIdCaddy(articleCourant.getId());
                    ArrayList<CaddyItem> articles = (ArrayList<CaddyItem>) caddyItemDAO.charger(rechercheCaddyItemVM);

                    for(CaddyItem article : articles)
                    {
                        LivreDAO livreDAO = new LivreDAO(connexionBD);
                        RechercheLivreVM rechercheLivreVM = new RechercheLivreVM();
                        rechercheLivreVM.setId(article.getId());
                        ArrayList<Livre> livres = (ArrayList<Livre>) livreDAO.chargerLivres(rechercheLivreVM);
                        int AjouterQuantite = livres.getFirst().getQuantite();
                        AjouterQuantite += article.getQuantity();
                        livreDAO.sauvegarder(livres.getFirst());
                        article.setQuantity(null);
                        caddyItemDAO.supprimer(article);
                    }

                    CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                    caddyDAO.delete(articleCourant);
                    articleCourant = null;
                    return new EffacerPanierReponse(true);
                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }

            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }

        }

        if(requete instanceof PayerPanierRequete)
        {
            try
            {
                if(clientCourant != null)
                {
                    if(articleCourant == null)
                    {
                        return new PayerPanierReponse(false);
                    }

                    else
                    {
                        CaddyDAO caddyDAO = new CaddyDAO(connexionBD);
                        articleCourant.setPaye(true);
                        caddyDAO.save(articleCourant);
                        articleCourant = null;
                        return new PayerPanierReponse(true);
                    }
                }

                else
                {
                    throw new Exception("Le client n'est pas connecté");
                }
            }
            catch(Exception e)
            {
                return new MessageErreur(e.getMessage());
            }
        }
        return null;
    }
}
