package ServeurJava.Reseaux.Protocole;

import ServeurJava.Logger.Logger;
import ServeurJava.Model.Base_De_Données.ConnexionBD;

public class UsineProtocole
{
    public static Protocole RecupererProtocole(Logger logger)
    {
        return new BSPP((ConnexionBD) logger);
    }
}
